Taruh gambar iklan di folder ini.
Contoh nama: ad1.jpg, ad2.jpg, ad3.jpg
Lalu edit src di: src/data/ads.js
