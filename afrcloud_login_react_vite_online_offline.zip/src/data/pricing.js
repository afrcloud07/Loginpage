// Edit paket & harga di sini
export const pricing = [
  { name: '2 JAM', desc: 'Speed 3Mbps', price: 'Rp 1.000' },
  { name: '6 JAM', desc: 'Speed 3Mbps', price: 'Rp 2.000' },
  { name: '12 JAM', desc: 'Speed 3Mbps', price: 'Rp 3.000' },
  { name: '18 JAM', desc: 'Speed 3Mbps', price: 'Rp 4.000' },
  { name: '1 HARI', desc: 'Hemat Mingguan.', price: 'Rp 5.000' },
  { name: '3 HARI', desc: 'Maksimal Sebulan.', price: 'Rp 10.000' }
]
