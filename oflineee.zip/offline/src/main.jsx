// Bridge entry for OFFLINE build.
// Vite root for offline build is `offline/`, but we reuse the same React app.
import '../../src/main.jsx'
