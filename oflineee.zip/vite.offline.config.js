import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'node:path'

export default defineConfig({
  // Use offline/ as Vite root so output files become:
  // dist/offline/login.html and dist/offline/status.html (no nested offline/ folder)
  root: resolve(__dirname, 'offline'),
  // Reuse the same public assets (ads, images, md5 helper, etc.)
  publicDir: resolve(__dirname, 'public'),
  plugins: [react()],
  // Relative base so the build can be dropped into MikroTik hotspot folder
  base: './',
  build: {
    outDir: resolve(__dirname, 'dist/offline'),
    emptyOutDir: true,
    assetsDir: 'assets',
    cssCodeSplit: false,
    rollupOptions: {
      // OFFLINE / MAINTENANCE pages
      // Output: login.html, status.html
      input: {
        login: resolve(__dirname, 'offline/login.html'),
        status: resolve(__dirname, 'offline/status.html')
      },
      output: {
        // Keep filenames stable (no hashes)
        entryFileNames: 'assets/[name].js',
        chunkFileNames: 'assets/chunk-[name].js',
        assetFileNames: 'assets/[name][extname]'
      }
    }
  }
})
