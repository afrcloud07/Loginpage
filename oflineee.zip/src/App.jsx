import LoginPage from './pages/LoginPage.jsx'
import ALoginPage from './pages/ALoginPage.jsx'
import RedirectPage from './pages/RedirectPage.jsx'
import LogoutPage from './pages/LogoutPage.jsx'
import StatusPage from './pages/StatusPage.jsx'
import ErrorPage from './pages/ErrorPage.jsx'
import OfflineLoginPage from './pages/OfflineLoginPage.jsx'
import OfflineStatusPage from './pages/OfflineStatusPage.jsx'

export default function App() {
  const page = (window.__PAGE__ || 'login').toLowerCase()
  const isOffline = Boolean(window.__OFFLINE__)

  // OFFLINE / MAINTENANCE build
  if (isOffline) {
    if (page === 'status') return <OfflineStatusPage />
    return <OfflineLoginPage />
  }

  switch (page) {
    case 'alogin':
      return <ALoginPage />
    case 'redirect':
      return <RedirectPage />
    case 'logout':
      return <LogoutPage />
    case 'status':
      return <StatusPage />
    case 'error':
      return <ErrorPage />
    case 'login':
    default:
      return <LoginPage />
  }
}
