import React, { useMemo, useState } from 'react'
import ShowcasePanel from '../components/ShowcasePanel.jsx'
import { getMT } from '../utils/mikrotik.js'

export default function OfflineLoginPage() {
  const mt = useMemo(() => getMT(), [])
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="split-container">
      <ShowcasePanel defaultTab="ads" />

      <div className={`login-area ${expanded ? 'expanded' : ''}`}>
        <div className="sheet-handle" onClick={() => setExpanded((v) => !v)} />

        <div className="login-header-mobile" onClick={() => setExpanded((v) => !v)}>
          <h2 className="login-title">MAINTENANCE</h2>
          <div className="cta-arrow">Klik Untuk Detail ▲</div>
        </div>

        <p className="login-subtitle" style={{ display: 'block' }}>
          Layanan hotspot sedang offline / maintenance.
        </p>

        <div className="card" style={{ padding: 18, borderRadius: 12, marginBottom: 18 }}>
          <div style={{ color: 'var(--text-muted)', fontWeight: 700, marginBottom: 10 }}>Info</div>
          <div style={{ color: '#fff', fontWeight: 700, lineHeight: 1.5 }}>
            Mohon tunggu beberapa saat. Silakan coba lagi setelah jaringan kembali normal.
          </div>
          <div style={{ marginTop: 12, color: 'var(--text-muted)', fontWeight: 700, lineHeight: 1.5 }}>
            SSID: {mt.identity || '-'}<br />
            IP: {mt.ip || '-'}<br />
            MAC: {mt.mac || '-'}
          </div>
        </div>

        <button className="btn btn-cyber" type="button" onClick={() => window.location.reload()}>
          COBA LAGI
        </button>

        {mt.linkStatus && mt.linkStatus !== '#' && (
          <a
            href={mt.linkStatus}
            className="btn btn-cancel"
            style={{ display: 'block', textAlign: 'center', textDecoration: 'none', marginTop: 12 }}
          >
            LIHAT STATUS
          </a>
        )}
      </div>
    </div>
  )
}
