import React, { useMemo, useState } from 'react'
import ShowcasePanel from '../components/ShowcasePanel.jsx'
import { getMT } from '../utils/mikrotik.js'

export default function OfflineStatusPage() {
  const mt = useMemo(() => getMT(), [])
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="split-container">
      <ShowcasePanel defaultTab="ads" />

      <div className={`login-area ${expanded ? 'expanded' : ''}`}>
        <div className="sheet-handle" onClick={() => setExpanded((v) => !v)} />

        <div className="login-header-mobile" onClick={() => setExpanded((v) => !v)}>
          <h2 className="login-title">STATUS MAINTENANCE</h2>
          <div className="cta-arrow">Klik Untuk Detail ▲</div>
        </div>

        <p className="login-subtitle" style={{ display: 'block' }}>
          Hotspot sedang offline / maintenance.
        </p>

        <div className="card" style={{ padding: 18, borderRadius: 12, marginBottom: 18 }}>
          <div style={{ color: 'var(--text-muted)', fontWeight: 700, marginBottom: 10 }}>Status</div>
          <div style={{ color: '#fff', fontWeight: 700, lineHeight: 1.5 }}>
            Sistem sedang perbaikan / internet sedang tidak tersedia.
          </div>
          <div style={{ marginTop: 12, color: 'var(--text-muted)', fontWeight: 700, lineHeight: 1.5 }}>
            Username: {mt.username || '-'}<br />
            Uptime: {mt.uptime || '-'}<br />
            IP: {mt.ip || '-'}
          </div>
        </div>

        <button className="btn btn-cyber" type="button" onClick={() => window.location.reload()}>
          COBA LAGI
        </button>

        {mt.linkLoginOnly && mt.linkLoginOnly !== '#' && (
          <a
            href={mt.linkLoginOnly}
            className="btn btn-cancel"
            style={{ display: 'block', textAlign: 'center', textDecoration: 'none', marginTop: 12 }}
          >
            KEMBALI
          </a>
        )}
      </div>
    </div>
  )
}
