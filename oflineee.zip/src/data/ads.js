// Tab IKLAN: daftar gambar slider.
// Letakkan file iklan di folder: /public/ads/
// Contoh: /public/ads/ad1.jpg  -> src: '/ads/ad1.jpg'

export const ads = [
  { src: '/ads/ad1.jpg', alt: 'Iklan 1' },
  { src: '/ads/ad2.jpg', alt: 'Iklan 2' },
  { src: '/ads/ad3.jpg', alt: 'Iklan 3' }
]
